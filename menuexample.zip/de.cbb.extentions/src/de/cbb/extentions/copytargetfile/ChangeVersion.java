package de.cbb.extentions.copytargetfile;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.core.resources.IProject;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.console.ConsolePlugin;
import org.eclipse.ui.console.IConsole;
import org.eclipse.ui.console.IConsoleManager;
import org.eclipse.ui.console.MessageConsole;
import org.eclipse.ui.console.MessageConsoleStream;

import de.cbb.extentions.dialogs.GetNewVersionDialog;

public class ChangeVersion implements IViewActionDelegate {
	/** Das selektierte Projekt */
	IStructuredSelection selection;
	/** Diese Variable schreibt in console */
	private MessageConsoleStream consoleOutput;
	/** Diese werden geskipped */
	final List<String> ignoredFolders = Arrays.asList("target", "bin", "repository");
	private String oldVersion;
	private String newVersion;

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	@Override
	public void run(final IAction action) {
		final MessageConsole myConsole = this.findConsole("Console");
		this.consoleOutput = myConsole.newMessageStream();

		if (!this.selection.isEmpty()) {
			final Iterator<?> iter = this.selection.iterator();
			while (iter.hasNext()) {
				final Object obj = iter.next();
				if (obj instanceof IProject) {
					final IProject project = (IProject) obj;
					this.consoleOutput.println("Project name    : " + project.getName());
					this.consoleOutput.println("Project folder  : " + project.getLocation().toOSString());

					this.oldVersion = this.getCurrentVersion(project);
					if (this.oldVersion.isEmpty()) {
						MessageDialog.openError(new Shell(),
								"Version des selektierten Komponentes konnte nicht ermittelt werden!",
								"Bitte prüfen, ob die Versionsangaben in all den mf- und xml-Dateien übereinstimmen.");
						return;
					}
					this.consoleOutput.println("Aktuelle Version: " + this.oldVersion);

					/* Gib dem dialog die aktuelle Version */
					final GetNewVersionDialog newVersionDlg = new GetNewVersionDialog(null, this.oldVersion);
					if (newVersionDlg.open() == Window.OK) {
						this.newVersion = newVersionDlg.getNewVersion();
						this.consoleOutput.println("Neue Version    : " + this.newVersion);
						this.replaceAllVersions(project, this.oldVersion, this.newVersion);
					}
				}
			}
		}
	}

	/**
	 * Ermittelt die Version des selektierten Komponentes aus dem parent-pom.xml
	 *
	 * @return Version als String. Bsp. 1.0.0
	 */
	private String getCurrentVersion(final IProject project) {
		final File fileRootPlugin = this.getRootPath(project);
		this.consoleOutput.println("Parent plug-in  : " + fileRootPlugin.getAbsolutePath());

		for (final File folder : fileRootPlugin.listFiles(File::isDirectory)) {
			if (folder.getName().endsWith(".parent")) {
				final File filePomXml = new File(folder, "pom.xml");
				try (BufferedReader br = new BufferedReader(new FileReader(filePomXml))) {
					String line;
					while ((line = br.readLine()) != null) {
						final Pattern pattern = Pattern.compile("<version>(\\d+).(\\d+).(\\d+)-SNAPSHOT</version>");
						final Matcher matcher = pattern.matcher(line);
						if (matcher.find()) {
							return matcher.group(1) + "." + matcher.group(2) + "." + matcher.group(3);
						}
					}
				} catch (final IOException e) {
					return "";
				}
			}
		}
		return "";
	}

	/**
	 * Gibt den Pfad des übergeordneten Ordners zurück. Bsp:
	 * /home/xyz/test/komponentname oder /home/xyz/test/komponentname.feature.
	 * Return wird /home/xyz/test.
	 */
	private File getRootPath(final IProject project) {
		final String projectPath = project.getLocation().toOSString();
		final String projectRootPath = projectPath.substring(0, projectPath.lastIndexOf(File.separator));
		return new File(projectRootPath);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.
	 * IAction, org.eclipse.jface.viewers.ISelection)
	 */
	@Override
	public void selectionChanged(final IAction action, final ISelection selection) {
		this.selection = (IStructuredSelection) selection;
	}

	public void dispose() {
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.ui.IViewActionDelegate#init(org.eclipse.ui.IViewPart)
	 */
	@Override
	public void init(final IViewPart view) {
		// Used for viewerContributions, not for objectContributions
	}

	/**
	 * To write to the console, you need to create your own IConsole instance and
	 * connect it to the Console view. To do this, you have to add a new dependency
	 * to org.eclipse.ui.console in the plugin.xml of your plugin. For a console
	 * containing a simple text document, you can instantiate a MessageConsole
	 * instance.
	 *
	 * @param name
	 * @return
	 */
	private MessageConsole findConsole(final String name) {
		final ConsolePlugin plugin = ConsolePlugin.getDefault();
		final IConsoleManager conMan = plugin.getConsoleManager();
		final IConsole[] existing = conMan.getConsoles();
		for (int i = 0; i < existing.length; i++) {
			if (name.equals(existing[i].getName())) {
				return (MessageConsole) existing[i];
			}
		}
		// no console found, so create a new one
		final MessageConsole myConsole = new MessageConsole(name, null);
		conMan.addConsoles(new IConsole[] { myConsole });
		return myConsole;
	}

	/**
	 * Ersetzt die alte-Version durch die neue Version in allen Dateien unter dem
	 * eingegebene Pfad
	 */
	private void replaceAllVersions(final IProject project, final String oldVersion, final String newVersion) {
		final File fileRootPlugin = this.getRootPath(project);
		final List<File> filesToEdit = new ArrayList<>();

		this.consoleOutput.println("Suche und ersetze die Version in xml und MF Dateien...");
		/* Finde all die Dateien, die angepasst werden müssen */
		for (final File folder : fileRootPlugin.listFiles(File::isDirectory)) {
			if (this.ignoredFolders.contains(folder.getName())) {
				this.consoleOutput.println("* Der Ordner [" + folder.getAbsolutePath() + "] wird übersprungen.");
				continue;
			}
			/* Hole alle xml-Dateien */
			filesToEdit.addAll(this.getXmlFiles(folder));
			/* Falls unter META-INF die MANIFEST.MF liegt, dann hol sie */
			final File fileMf = new File(folder, "META-INF");
			if (fileMf.isDirectory()) {
				filesToEdit.add(new File(fileMf, "MANIFEST.MF"));
			}
		}

		this.setNewVersion(filesToEdit);
	}

	/**
	 * Sucht unter dem eingegebenem Ordner rekursiv die xml und mf Dateien. Falls
	 * gefunden, wird die Version angepasst.
	 */
	private List<File> getXmlFiles(final File folder) {
		final List<File> xmlFiles = new ArrayList<>();

		/* Suche nach xml und mf-Dateien */
		for (final File file : folder.listFiles(File::isFile)) {
			if (this.isXmlFile(file)) {
				xmlFiles.add(file);
			}
		}

		return xmlFiles;
	}

	/**
	 * Prüft, ob die Datei eine xml-Datei ist.
	 */
	private boolean isXmlFile(final File file) {
		return "xml".equals(this.getFileExtention(file));
	}

	/*
	 * Gibt die Dateierweiterung zurück.
	 */
	private String getFileExtention(final File file) {
		if (!file.isFile()) {
			return "";
		}

		final String filename = file.getName();
		return filename.substring(filename.lastIndexOf(".") + 1, filename.length());
	}

	/**
	 * Ersetzt die alte Version durch die neue Version
	 */
	private void setNewVersion(final List<File> filesToEdit) {
		for (final File file : filesToEdit) {
			try {
				/* Zunächst versuche SNAPSHOT */
				String oldContent = this.oldVersion + "-SNAPSHOT";
				String newContent = this.newVersion + "-SNAPSHOT";
				this.replaceText(file, oldContent, newContent);

				/* Dann qualifier */
				oldContent = this.oldVersion + ".qualifier";
				newContent = this.newVersion + ".qualifier";
				this.replaceText(file, oldContent, newContent);
			} catch (final IOException e) {
				this.consoleOutput
						.println("  - Die Datei [" + file.getAbsolutePath() + "] konnte nicht angepasst werden.");
			}
		}
	}

	/**
	 * Ersetzt in einer Datei alle oldContent durch newContent
	 */
	private void replaceText(final File file, final String oldContent, final String newContent) throws IOException {
		final Path path = Paths.get(file.getAbsolutePath());
		final Charset charset = StandardCharsets.UTF_8;

		String fileContent = new String(Files.readAllBytes(path), charset);
		if (fileContent.contains(oldContent)) {
			this.consoleOutput.println("* Bearbeite die Datei: [" + file.getAbsolutePath());
			this.consoleOutput.print("  - Ersetze [" + oldContent + "] durch [" + newContent + "]...");
			fileContent = fileContent.replaceAll(oldContent, newContent);
			Files.write(path, fileContent.getBytes(charset));
			this.consoleOutput.println("OK");
		}
	}
}
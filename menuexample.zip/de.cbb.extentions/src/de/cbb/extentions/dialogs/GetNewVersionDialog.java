package de.cbb.extentions.dialogs;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

/**
 * Holt die neue Version
 */
public class GetNewVersionDialog extends Dialog {
	private final String oldVersion;
	private Text txtVersion;
	private String newVersion;

	public GetNewVersionDialog(final Shell parentShell, final String oldVersion) {
		super(parentShell);
		this.oldVersion = oldVersion;
	}

	@Override
	protected Control createDialogArea(final Composite parent) {
		final Composite area = (Composite) super.createDialogArea(parent);
		final Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		final GridLayout layout = new GridLayout(2, false);
		container.setLayout(layout);

		this.createInfoLabel(container);
		this.createTextField(container);
		//

		return container;
	}

	private void createInfoLabel(final Composite container) {
		/* Info label erstellen */
		final Label lblInitVersion = new Label(container, SWT.NONE);
		lblInitVersion.setText("Die aus parent-pom ermittelte Version ist: " + this.oldVersion);

		final GridData griddata = new GridData(GridData.FILL_HORIZONTAL);
		griddata.horizontalSpan = 2;
		lblInitVersion.setLayoutData(griddata);

	}

	private void createTextField(final Composite container) {
		/* Textfeld erstellen */
		final Label lblVersion = new Label(container, SWT.NONE);
		lblVersion.setText("Die neue Version eingeben");

		final GridData griddata = new GridData();
		griddata.grabExcessHorizontalSpace = true;
		griddata.horizontalAlignment = GridData.FILL;

		this.txtVersion = new Text(container, SWT.BORDER);
		this.txtVersion.setLayoutData(griddata);
	}

	// overriding this methods allows you to set the
	// title of the custom dialog
	@Override
	protected void configureShell(final Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Selection dialog");
	}

	@Override
	protected Point getInitialSize() {
		return new Point(450, 300);
	}

	@Override
	protected boolean isResizable() {
		return true;
	}

	@Override
	protected void okPressed() {
		/* Die Version aus dialog lesen */
		final String dlgVersion = this.txtVersion.getText();

		/* prüfe, ob syntax stimmt */
		final Pattern pattern = Pattern.compile("^(\\d+).(\\d+).(\\d+)$");
		final Matcher matcher = pattern.matcher(dlgVersion);
		if (!matcher.find()) {
			MessageDialog.openError(this.getShell(), "Die eingegebene Version hat falsche Syntax!",
					"Bitte prüfen, ob die Versionsangaben in Form Zahl.Zahl.Zahl ist. Bsp. 1.2.0");
			return;
		}
		/* Neue Version soll was neues sein */
		if (dlgVersion.equals(this.oldVersion)) {
			MessageDialog.openError(this.getShell(), "Ey... die Version ist nicht neu.",
					"Die neue und alte Version sind identisch.");
			return;
		}

		/* Alles gut */
		this.newVersion = dlgVersion;

		super.okPressed();
	}

	public String getNewVersion() {
		return this.newVersion;
	}
}
